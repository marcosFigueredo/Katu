# Figures directory

Institutional logos and UN SDG icons are intentionally not bundled in this CTAN upload because they may be subject to trademark or third-party usage rules.

The example document still compiles without them: `classPPGMSB` prints placeholders for missing institutional logos and simply omits missing SDG icons.

Users can add their local image files here, for example:

- `logo_uneb.jpg`
- `ppgmsbLogo.png`
- `logoso.png`
- `ods3.png`, `ods7.png`, etc.

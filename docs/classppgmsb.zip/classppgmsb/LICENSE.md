LaTeX Project Public License 1.3c

This work may be distributed and/or modified under the conditions of the
LaTeX Project Public License, either version 1.3c of this license or, at
your option, any later version.

The latest version of this license is available at:

https://www.latex-project.org/lppl.txt

This work has the LPPL maintenance status `maintained`.

The Current Maintainer of this work is Marcos Batista Figueredo.
